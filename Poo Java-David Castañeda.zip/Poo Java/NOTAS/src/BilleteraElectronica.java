import java.util.Scanner;

public class BilleteraElectronica {
    private double capital;

    public BilleteraElectronica() {
        this.capital = 0.0;
    }

    public void depositar(double cantidad) {
        capital += cantidad;
        System.out.println("Se depositaron $" + cantidad + " en la billetera.");
    }

    public void retirar(double cantidad) {
        if (cantidad <= capital) {
            capital -= cantidad;
            System.out.println("Se retiraron $" + cantidad + " de la billetera.");
        } else {
            System.out.println("No se puede retirar esa cantidad. Fondos insuficientes.");
        }
    }

    public double getCapital() {
        return capital;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BilleteraElectronica billetera = new BilleteraElectronica();

        int opcion;
        do {
            System.out.println("\nMenú:");
            System.out.println("1. Depositar dinero");
            System.out.println("2. Retirar dinero");
            System.out.println("3. Consultar capital");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese la cantidad a depositar: $");
                    double cantidadDeposito = scanner.nextDouble();
                    billetera.depositar(cantidadDeposito);
                    break;
                case 2:
                    System.out.print("Ingrese la cantidad a retirar: $");
                    double cantidadRetiro = scanner.nextDouble();
                    billetera.retirar(cantidadRetiro);
                    break;
                case 3:
                    System.out.println("Capital actual en la billetera: $" + billetera.getCapital());
                    break;
                case 4:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida. Inténtelo de nuevo.");
            }
        } while (opcion != 4);

        scanner.close();
    }
}
