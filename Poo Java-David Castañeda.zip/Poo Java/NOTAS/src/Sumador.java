public class Sumador {
    // Método para sumar tres números enteros
    public int sumar(int num1, int num2, int num3) {
        return num1 + num2 + num3;
    }

    // Método para sumar tres números flotantes
    public float sumar(float num1, float num2, float num3) {
        return num1 + num2 + num3;
    }

    // Método para sumar tres números double
    public double sumar(double num1, double num2, double num3) {
        return num1 + num2 + num3;
    }

    public static void main(String[] args) {
        Sumador sumador = new Sumador();

        // Sumar tres números enteros
        int resultadoEntero = sumador.sumar(10, 20, 30);
        System.out.println("Suma de tres enteros: " + resultadoEntero);

        // Sumar tres números flotantes
        float resultadoFlotante = sumador.sumar(10.5f, 20.5f, 30.5f);
        System.out.println("Suma de tres flotantes: " + resultadoFlotante);

        // Sumar tres números double
        double resultadoDouble = sumador.sumar(10.5, 20.5, 30.5);
        System.out.println("Suma de tres doubles: " + resultadoDouble);
    }
}
