import java.util.Scanner;

public class Convertidor {
    // Atributos
    private double cantidadPesos;
    private final double tasaDolar = 0.00027; // Tasa de conversión de pesos a dólares
    private final double tasaEuro = 0.00023;  // Tasa de conversión de pesos a euros

    // Métodos Set y Get para la cantidad de pesos
    public void setCantidadPesos(double cantidadPesos) {
        this.cantidadPesos = cantidadPesos;
    }

    public double getCantidadPesos() {
        return cantidadPesos;
    }

    // Método para convertir pesos a dólares
    public double convertirDolares() {
        return cantidadPesos * tasaDolar;
    }

    // Método para convertir pesos a euros
    public double convertirEuros() {
        return cantidadPesos * tasaEuro;
    }

    // Override del método toString para proporcionar una representación legible del objeto
    @Override
    public String toString() {
        return "Convertidor [cantidadPesos=" + cantidadPesos + "]";
    }

    // Método main para probar la clase Convertidor
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Crear objeto Convertidor
        Convertidor convertidor = new Convertidor();

        // Solicitar al usuario la cantidad de pesos a convertir
        System.out.print("Ingrese la cantidad de pesos a convertir: ");
        double cantidadPesos = scanner.nextDouble();

        // Establecer la cantidad de pesos en el convertidor
        convertidor.setCantidadPesos(cantidadPesos);

        // Realizar las conversiones y mostrar los resultados
        System.out.println("Cantidad de pesos ingresados: " + convertidor.getCantidadPesos());
        System.out.println("Valor en dólares: $" + convertidor.convertirDolares());
        System.out.println("Valor en euros: €" + convertidor.convertirEuros());

        // Cerrar el scanner
        scanner.close();
    }
}
