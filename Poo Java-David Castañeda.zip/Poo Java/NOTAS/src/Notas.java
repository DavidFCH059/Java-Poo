public class Notas {
    // Atributos
    private String documento;
    private String asignatura;
    private double nota60;
    private double nota40;

    // Constructor
    public Notas(String documento, String asignatura, double nota60, double nota40) {
        this.documento = documento;
        this.asignatura = asignatura;
        this.nota60 = nota60;
        this.nota40 = nota40;
    }

    // Métodos Set y Get para los atributos
    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getDocumento() {
        return documento;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setNota60(double nota60) {
        this.nota60 = nota60;
    }

    public double getNota60() {
        return nota60;
    }

    public void setNota40(double nota40) {
        this.nota40 = nota40;
    }

    public double getNota40() {
        return nota40;
    }

    // Método para calcular la nota final
    public double calcularNotaFinal() {
        return nota60 * 0.6 + nota40 * 0.4;
    }

    // Override del método toString para proporcionar una representación legible del objeto
    @Override
    public String toString() {
        return "Notas [documento=" + documento + ", asignatura=" + asignatura + ", nota60=" + nota60 + ", nota40="
                + nota40 + "]";
    }

    // Método para verificar si el estudiante aprobó o no
    public boolean aprobado() {
        return calcularNotaFinal() >= 3.0;
    }

    // Método main para probar la clase Notas
    public static void main(String[] args) {
        // Crear dos objetos Notas
        Notas estudiante1 = new Notas("123456789", "Matemáticas", 4.5, 3.8);
        Notas estudiante2 = new Notas("987654321", "Historia", 3.0, 2.5);

        // Imprimir los detalles de los estudiantes y si aprobaron o no
        System.out.println("Detalles del estudiante 1:");
        System.out.println(estudiante1);
        System.out.println("Nota final: " + estudiante1.calcularNotaFinal());
        System.out.println("¿Aprobado? " + (estudiante1.aprobado() ? "Sí" : "No"));

        System.out.println();

        System.out.println("Detalles del estudiante 2:");
        System.out.println(estudiante2);
        System.out.println("Nota final: " + estudiante2.calcularNotaFinal());
        System.out.println("¿Aprobado? " + (estudiante2.aprobado() ? "Sí" : "No"));
    }
}
