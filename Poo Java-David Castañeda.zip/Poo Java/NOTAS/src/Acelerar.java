import java.util.Scanner;

public class Acelerar {
    private String marca;
    private int velocidadActual;
    private final int velocidadMaxima;
    private final int velocidadMinima;
    private final int aceleracion;
    private final int desaceleracion;

    public Acelerar(String marca, int velocidadMaxima, int velocidadMinima, int aceleracion, int desaceleracion) {
        this.setMarca(marca);
        this.velocidadActual = 0;
        this.velocidadMaxima = velocidadMaxima;
        this.velocidadMinima = velocidadMinima;
        this.aceleracion = aceleracion;
        this.desaceleracion = desaceleracion;
    }

    public void acelerar() {
        if (velocidadActual + aceleracion <= velocidadMaxima) {
            velocidadActual += aceleracion;
            System.out.println("El vehículo aceleró. Velocidad actual: " + velocidadActual);
        } else {
            System.out.println("El vehículo alcanzó la velocidad máxima: " + velocidadMaxima);
        }
    }

    public void desacelerar() {
        if (velocidadActual - desaceleracion >= velocidadMinima) {
            velocidadActual -= desaceleracion;
            System.out.println("El vehículo desaceleró. Velocidad actual: " + velocidadActual);
        } else {
            System.out.println("El vehículo alcanzó la velocidad mínima: " + velocidadMinima);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Crear un vehículo con velocidad máxima de 100 km/h, velocidad mínima de 0 km/h,
        // aceleración de 10 km/h y desaceleración de 5 km/h
        Acelerar vehiculo = new Acelerar("Toyota", 100, 0, 10, 5);

        // Menú de opciones
        int opcion;
        do {
            System.out.println("\nMenú:");
            System.out.println("1. Acelerar");
            System.out.println("2. Desacelerar");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    vehiculo.acelerar();
                    break;
                case 2:
                    vehiculo.desacelerar();
                    break;
                case 3:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida. Inténtelo de nuevo.");
            }
        } while (opcion != 3);

        scanner.close();
    }

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}
}
